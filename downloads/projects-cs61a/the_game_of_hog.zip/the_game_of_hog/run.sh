#!/bin/bash
#--------------------------------------------------------
#These are functions that are useful for all bash scripts
#--------------------------------------------------------

#Pauses like windows dos pause commnad.
function pause(){
    read -rsp $'Press any key to continue...' -n1 key
}

function eof(){
    echo ""
    read -rsp $'Press any key to exit...' -n1 key
    exit
}

while true; do
    clear
    echo "Welcome to The Game of Hog Bash Launcher."
    echo ""
    echo "1. Hog 1 player (against my final strategy)"
    echo "2. Hog 2 player"
    echo "E. Exit"
    echo ""
    echo "Please select your choice."
    printf '>'
    read -r c

    if [ "$c" = "1" ]; then
        python3 hog_gui.pyc
        eof
    elif [ "$c" = "2" ]; then
        python3 hog_gui.pyc -f
        eof 
    elif [ "${c,,}" = "e" ] || [ "${c,,}" = "exit" ]; then
        eof
    fi
done