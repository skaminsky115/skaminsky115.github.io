#!/bin/bash
echo "A Scheme interpreter written by Stephan Kaminsky and Noah Pepper."
python3 scheme.pyc